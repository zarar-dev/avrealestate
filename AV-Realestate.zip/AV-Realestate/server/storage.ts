import { eq } from "drizzle-orm";
import { db } from "./db";
import { 
  users, 
  properties, 
  contactSubmissions,
  type User, 
  type InsertUser, 
  type Property, 
  type InsertProperty, 
  type ContactSubmission, 
  type InsertContact 
} from "@shared/schema";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllProperties(): Promise<Property[]>;
  getFeaturedProperties(): Promise<Property[]>;
  getProperty(id: string): Promise<Property | undefined>;
  searchProperties(query: string): Promise<Property[]>;
  createProperty(property: InsertProperty): Promise<Property>;
  
  createContact(contact: InsertContact): Promise<ContactSubmission>;
  getAllContacts(): Promise<ContactSubmission[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getAllProperties(): Promise<Property[]> {
    return db.select().from(properties);
  }

  async getFeaturedProperties(): Promise<Property[]> {
    return db.select().from(properties).where(eq(properties.featured, true));
  }

  async getProperty(id: string): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.id, id));
    return property;
  }

  async searchProperties(query: string): Promise<Property[]> {
    const allProperties = await db.select().from(properties);
    const lowerQuery = query.toLowerCase();
    return allProperties.filter(p => 
      p.title.toLowerCase().includes(lowerQuery) ||
      p.neighborhood.toLowerCase().includes(lowerQuery) ||
      p.address.toLowerCase().includes(lowerQuery) ||
      p.propertyType.toLowerCase().includes(lowerQuery)
    );
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const [property] = await db.insert(properties).values(insertProperty).returning();
    return property;
  }

  async createContact(insertContact: InsertContact): Promise<ContactSubmission> {
    const [contact] = await db.insert(contactSubmissions).values(insertContact).returning();
    return contact;
  }

  async getAllContacts(): Promise<ContactSubmission[]> {
    return db.select().from(contactSubmissions);
  }
}

export const storage = new DatabaseStorage();
