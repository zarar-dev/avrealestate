import { db } from "./db";
import { properties, type InsertProperty } from "@shared/schema";

const sampleProperties: InsertProperty[] = [
  {
    title: "The Yorkville Penthouse",
    address: "200 Bloor Street West, PH01",
    neighborhood: "Yorkville",
    price: 3500000,
    bedrooms: 4,
    bathrooms: "4.5",
    squareFeet: 4200,
    propertyType: "Penthouse",
    description: "Exceptional penthouse offering panoramic city views, private terrace, and custom finishes throughout.",
    imageUrl: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
  {
    title: "Forest Hill Estate",
    address: "145 Old Forest Hill Road",
    neighborhood: "Forest Hill",
    price: 4900000,
    bedrooms: 6,
    bathrooms: "7",
    squareFeet: 8500,
    propertyType: "Estate",
    description: "Masterfully renovated estate on a prestigious street, featuring luxury amenities and mature landscaping.",
    imageUrl: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
  {
    title: "King West Loft",
    address: "560 King Street West, Unit 2201",
    neighborhood: "King West",
    price: 1250000,
    bedrooms: 2,
    bathrooms: "2",
    squareFeet: 1850,
    propertyType: "Loft",
    description: "Stunning industrial loft conversion with 14-foot ceilings, exposed brick, and designer finishes.",
    imageUrl: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
  {
    title: "Rosedale Heritage Home",
    address: "88 Crescent Road",
    neighborhood: "Rosedale",
    price: 2200000,
    bedrooms: 5,
    bathrooms: "5",
    squareFeet: 5200,
    propertyType: "Heritage",
    description: "Meticulously restored Victorian home with modern amenities, private garden, and coach house.",
    imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
  {
    title: "Distillery District Condo",
    address: "33 Mill Street, Suite 802",
    neighborhood: "Distillery",
    price: 850000,
    bedrooms: 2,
    bathrooms: "2",
    squareFeet: 1200,
    propertyType: "Condo",
    description: "Contemporary condo in historic Distillery District with exposed beams and designer kitchen.",
    imageUrl: "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
  {
    title: "Leslieville Townhouse",
    address: "125 Carlaw Avenue",
    neighborhood: "Leslieville",
    price: 1150000,
    bedrooms: 3,
    bathrooms: "2.5",
    squareFeet: 1800,
    propertyType: "Townhouse",
    description: "Modern townhouse in trendy Leslieville with rooftop terrace and open-concept living.",
    imageUrl: "https://images.unsplash.com/photo-1605276374104-dee2a0ed3cd6?w=800&h=600&fit=crop",
    featured: true,
    status: "Sold",
  },
];

export async function seedDatabase() {
  try {
    const existingProperties = await db.select().from(properties);
    
    if (existingProperties.length === 0) {
      console.log("Seeding database with sample properties...");
      await db.insert(properties).values(sampleProperties);
      console.log(`Seeded ${sampleProperties.length} properties successfully!`);
    } else {
      console.log(`Database already has ${existingProperties.length} properties, skipping seed.`);
    }
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
