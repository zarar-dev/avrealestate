import { SiInstagram } from "react-icons/si";
import { Phone, Mail, MapPin } from "lucide-react";
import logoUrl from "@assets/image_1768945695247.png";
import royalLepageLogo from "@assets/image_1768946315225.png";

import royal_lepage_vector_logo_download_free_11574046615ereeqdyh9p from "@assets/royal-lepage-vector-logo-download-free-11574046615ereeqdyh9p.png";

const footerLinks = [
  { label: "Buy", href: "#properties" },
  { label: "Sell", href: "#services" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

const serviceLinks = [
  { label: "Home Buying", href: "#services" },
  { label: "Home Selling", href: "#services" },
  { label: "Pre-Construction", href: "#services" },
  { label: "Market Analysis", href: "#services" },
];

export function Footer() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-foreground text-background py-12 lg:py-16 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div className="lg:col-span-1">
            <a
              href="#"
              className="flex items-center gap-2 mb-4"
              data-testid="link-footer-home"
            >
              <img 
                src={logoUrl} 
                alt="Adnaan Vania Real Estate" 
                className="h-12 w-auto invert"
              />
            </a>
            <div className="mb-4 inline-block">
              <img 
                src={royal_lepage_vector_logo_download_free_11574046615ereeqdyh9p} 
                alt="Royal LePage" 
                className="h-10 w-auto"
                data-testid="img-royal-lepage-logo"
              />
            </div>
            <p className="text-background/70 text-sm mb-2" data-testid="text-footer-description">
              Sales Representative, Royal LePage Your Community Realty, Brokerage
            </p>
            <p className="text-background/50 text-xs mb-4">
              Independently Owned and Operated
            </p>
            <a
              href="https://www.instagram.com/adnaanvania"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 text-sm border border-background/30 text-background rounded-full hover:bg-background/10 transition-colors"
              data-testid="link-social-instagram"
            >
              <SiInstagram className="w-4 h-4" />
              @adnaanvania
            </a>
          </div>

          <div>
            <h4 className="font-semibold text-background mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {footerLinks.map((link) => (
                <li key={link.label}>
                  <button
                    className="text-sm text-background/70 hover:text-background transition-colors"
                    onClick={() => scrollToSection(link.href)}
                    data-testid={`link-footer-${link.label.toLowerCase()}`}
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-background mb-4">Services</h4>
            <ul className="space-y-2">
              {serviceLinks.map((link) => (
                <li key={link.label}>
                  <button
                    className="text-sm text-background/70 hover:text-background transition-colors"
                    onClick={() => scrollToSection(link.href)}
                    data-testid={`link-footer-service-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-background mb-4">Contact</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-primary mt-0.5" />
                <a 
                  href="tel:+14162380010" 
                  className="text-background/70 hover:text-background transition-colors"
                  data-testid="link-footer-phone"
                >
                  (416) 238-0010
                </a>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 text-primary mt-0.5" />
                <a 
                  href="mailto:avsoldd@gmail.com" 
                  className="text-background/70 hover:text-background transition-colors"
                  data-testid="link-footer-email"
                >
                  avsoldd@gmail.com
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-primary mt-0.5" />
                <span className="text-background/70" data-testid="text-footer-address">
                  Toronto, Ontario
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-background/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-background/60" data-testid="text-copyright">
            &copy; {new Date().getFullYear()} Adnaan Vania. Royal LePage Your Community Realty, Brokerage.
          </p>
          <div className="flex items-center gap-4">
            <button className="text-xs text-background/60 hover:text-background transition-colors" data-testid="link-privacy">
              Privacy Policy
            </button>
            <button className="text-xs text-background/60 hover:text-background transition-colors" data-testid="link-terms">
              Terms of Service
            </button>
          </div>
        </div>

        <div className="pt-6 text-center">
          <p className="text-sm text-background/50">
            Website powered by{" "}
            <a 
              href="https://yzautomations.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary font-semibold hover:text-primary/80 transition-colors"
              data-testid="link-yzautomation"
            >
              yzautomation
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}
