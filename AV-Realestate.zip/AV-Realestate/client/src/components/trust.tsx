import { motion, useInView, useMotionValue, useTransform, animate } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { Star, Award, TrendingUp, Users, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { SiInstagram } from "react-icons/si";
import adnanPhotoUrl from "@assets/image_1768949475436.png";

const stats = [
  { icon: Home, value: 20, suffix: "+", label: "Homes Sold" },
  { icon: TrendingUp, value: 10, suffix: "M+", label: "Total Sales Volume", prefix: "$" },
  { icon: Users, value: 5, suffix: "+", label: "Years in Business" },
  { icon: Award, value: 98, suffix: "%", label: "Client Satisfaction" },
];

const testimonials = [
  {
    name: "David & Priya",
    role: "Bought in Vaughan",
    content: "Adnaan helped us find our home in Vaughan when inventory was really tight. He was patient and knew exactly what to look for.",
    rating: 5,
  },
  {
    name: "The Nguyen Family",
    role: "Sold in Richmond Hill",
    content: "We got multiple offers within the first week. Adnaan's pricing strategy worked perfectly for us.",
    rating: 5,
  },
  {
    name: "Mark S.",
    role: "Investor",
    content: "I've worked with Adnaan on three properties now. He understands the investment side of real estate really well.",
    rating: 5,
  },
];

function AnimatedCounter({ value, suffix, prefix, isInView }: { value: number; suffix: string; prefix?: string; isInView: boolean }) {
  const [displayValue, setDisplayValue] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (isInView && !hasAnimated.current) {
      hasAnimated.current = true;
      const duration = 2000;
      const steps = 60;
      const increment = value / steps;
      let current = 0;
      
      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setDisplayValue(value);
          clearInterval(timer);
        } else {
          setDisplayValue(Math.floor(current));
        }
      }, duration / steps);

      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span className="text-3xl font-bold text-foreground tabular-nums">
      {prefix}{displayValue}{suffix}
    </span>
  );
}

export function Trust() {
  const sectionRef = useRef(null);
  const statsRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });
  const statsInView = useInView(statsRef, { once: true, margin: "-50px" });

  return (
    <section id="about" className="py-16 lg:py-24 px-4 lg:px-8 bg-muted/30" ref={sectionRef}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="text-about-title">
            Trusted by Hundreds of Families
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Royal LePage Sales Representative helping clients across the Greater Toronto Area
          </p>
        </motion.div>

        <div 
          ref={statsRef}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={statsInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="text-center"
              data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <stat.icon className="w-7 h-7 text-primary" />
              </div>
              <AnimatedCounter value={stat.value} suffix={stat.suffix} prefix={(stat as any).prefix} isInView={statsInView} />
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -40 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col md:flex-row gap-8 items-start"
          >
            <div className="flex-shrink-0">
              <div className="relative">
                <img 
                  src={adnanPhotoUrl} 
                  alt="Adnaan Vania - Real Estate Sales Representative" 
                  className="w-48 h-auto rounded-2xl shadow-lg object-cover"
                  data-testid="img-adnan-photo"
                />
                <div className="absolute -bottom-3 -right-3 bg-primary text-primary-foreground px-3 py-1 rounded-full text-xs font-medium shadow-lg">Adnaan Vania</div>
              </div>
            </div>
            
            <div className="flex-1">
              <h3 className="text-xl font-bold text-foreground mb-2">
                About Adnaan Vania
              </h3>
              <p className="text-base text-muted-foreground mb-4" data-testid="text-about-role">
                Sales Representative at Royal LePage Your Community Realty
              </p>
              
              <div className="space-y-4 text-muted-foreground mb-6">
                <p data-testid="text-about-bio-1">
                  I've been helping people buy and sell homes across the GTA for over 5 years. From first-time buyers in Brampton to investors looking at pre-construction in downtown Toronto, I bring dedication to every transaction.
                </p>
                <p data-testid="text-about-bio-2">
                  Real estate isn't just about transactions. It's about understanding what matters to you and making the process as smooth as possible. That's why most of my business comes from referrals and repeat clients.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <a
                  href="https://www.instagram.com/adnaanvania"
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="link-instagram"
                >
                  <Button variant="outline" className="gap-2 rounded-xl">
                    <SiInstagram className="w-5 h-5" />
                    Follow on Instagram
                  </Button>
                </a>
                <Button 
                  className="rounded-xl"
                  onClick={() => {
                    const element = document.querySelector("#contact");
                    if (element) element.scrollIntoView({ behavior: "smooth" });
                  }} 
                  data-testid="button-schedule-call"
                >
                  Schedule a Call
                </Button>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 40 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="space-y-4"
          >
            <h3 className="text-lg font-semibold text-foreground mb-4" data-testid="text-testimonials-title">
              What My Clients Say
            </h3>
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: 0.5 + index * 0.1 }}
              >
                <Card
                  className="p-5 rounded-xl"
                  data-testid={`card-testimonial-${index}`}
                >
                  <div className="flex gap-1 mb-3">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-muted-foreground text-sm mb-3">"{testimonial.content}"</p>
                  <div>
                    <p className="font-medium text-foreground text-sm">{testimonial.name}</p>
                    <p className="text-xs text-muted-foreground">{testimonial.role}</p>
                  </div>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
