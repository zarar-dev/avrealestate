import { useState } from "react";
import { motion } from "framer-motion";
import { Search, MapPin, Home, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import logoUrl from "@assets/image_1768945695247.png";

interface HeroProps {
  onSearch?: (query: string, type: string) => void;
}

export function Hero({ onSearch }: HeroProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [propertyType, setPropertyType] = useState<"buy" | "rent">("buy");

  const handleSearch = () => {
    if (onSearch) {
      onSearch(searchQuery, propertyType);
    }
    const element = document.querySelector("#properties");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="hero" className="relative">
      <div className="relative min-h-[100vh] overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1517090504586-fde19ea6066f?w=1920&h=1080&fit=crop')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/60" />

        <div className="relative z-10 h-full min-h-[100vh] flex flex-col justify-center items-center px-4 lg:px-8 py-20">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-center max-w-4xl mx-auto"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="mb-8"
            >
              <img 
                src={logoUrl} 
                alt="Adnaan Vania Real Estate" 
                className="h-24 md:h-32 w-auto mx-auto invert"
                data-testid="img-hero-logo"
              />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-3xl md:text-4xl lg:text-6xl font-bold text-white leading-tight mb-6"
              data-testid="text-hero-title"
            >
              Toronto Real Estate
              <br />
              <span className="font-normal text-white/90">Done Right</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-base md:text-lg text-white/70 mb-8 max-w-xl mx-auto"
              data-testid="text-hero-description"
            >
              Buying or selling in the GTA? I'm here to make it simple. Royal LePage Sales Representative with 5+ years experience.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="bg-white rounded-2xl shadow-2xl p-4 md:p-6 max-w-2xl mx-auto"
            >
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    placeholder="Enter city, neighborhood, or address"
                    className="pl-10 rounded-xl"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                    data-testid="input-search-location"
                  />
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant={propertyType === "buy" ? "default" : "outline"}
                    size="default"
                    className="rounded-xl"
                    onClick={() => setPropertyType("buy")}
                    data-testid="button-filter-buy"
                  >
                    <Home className="w-4 h-4 mr-2" />
                    Buy
                  </Button>
                  <Button 
                    variant={propertyType === "rent" ? "default" : "outline"}
                    size="default"
                    className="rounded-xl"
                    onClick={() => setPropertyType("rent")}
                    data-testid="button-filter-rent"
                  >
                    <Building2 className="w-4 h-4 mr-2" />
                    Rent
                  </Button>
                  <Button 
                    size="default"
                    className="rounded-xl"
                    onClick={handleSearch}
                    data-testid="button-search-properties"
                  >
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.9 }}
              className="flex flex-wrap justify-center gap-8 mt-12"
            >
              <div className="text-center text-white">
                <p className="text-3xl md:text-4xl font-bold" data-testid="stat-homes-sold">20+</p>
                <p className="text-sm text-white/70">Homes Sold</p>
              </div>
              <div className="text-center text-white">
                <p className="text-3xl md:text-4xl font-bold" data-testid="stat-experience">5+</p>
                <p className="text-sm text-white/70">Years Experience</p>
              </div>
              <div className="text-center text-white">
                <p className="text-3xl md:text-4xl font-bold" data-testid="stat-volume">$10M+</p>
                <p className="text-sm text-white/70">Total Volume</p>
              </div>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.2 }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2"
          >
            <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center pt-2">
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="w-1.5 h-1.5 bg-white rounded-full"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
