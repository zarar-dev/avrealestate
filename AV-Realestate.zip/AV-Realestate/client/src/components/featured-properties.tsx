import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { type Property } from "@shared/schema";
import { MapPin, Bed, Bath, Square, Heart, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-CA', {
    style: 'currency',
    currency: 'CAD',
    maximumFractionDigits: 0,
  }).format(price);
}

interface PropertyCardProps {
  property: Property;
  index: number;
  onFavorite: (id: string) => void;
  isFavorited: boolean;
}

function PropertyCard({ property, index, onFavorite, isFavorited }: PropertyCardProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group bg-card rounded-lg overflow-hidden shadow-md hover-elevate"
      data-testid={`card-property-${property.id}`}
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={property.imageUrl}
          alt={property.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3 flex gap-2">
          <Badge variant="secondary" className="backdrop-blur-md border-none bg-[#ff0000cc]">
            {property.propertyType}
          </Badge>
        </div>
        <Button 
          variant={isFavorited ? "default" : "secondary"}
          size="icon"
          className="absolute top-3 right-3"
          onClick={() => onFavorite(property.id)}
          data-testid={`button-favorite-${property.id}`}
        >
          <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
        </Button>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div className="flex flex-col">
            <div className="mt-1">
              <Badge className="bg-primary text-white border-none text-[10px] py-0 px-1.5 h-4 uppercase font-bold tracking-wider">
                Sold
              </Badge>
            </div>
          </div>
        </div>
        
        <p className="text-sm text-foreground font-medium mb-1" data-testid={`text-property-title-${property.id}`}>
          {property.title}
        </p>
        
        <div className="flex items-center gap-1 text-muted-foreground mb-3">
          <MapPin className="w-4 h-4" />
          <span className="text-sm" data-testid={`text-location-${property.id}`}>
            {property.neighborhood}, Toronto
          </span>
        </div>

        <div className="flex items-center gap-4 pt-3 border-t border-border text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Bed className="w-4 h-4" />
            <span data-testid={`text-beds-${property.id}`}>{property.bedrooms} bd</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="w-4 h-4" />
            <span data-testid={`text-baths-${property.id}`}>{property.bathrooms} ba</span>
          </div>
          <div className="flex items-center gap-1">
            <Square className="w-4 h-4" />
            <span data-testid={`text-sqft-${property.id}`}>{property.squareFeet.toLocaleString()} sqft</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function PropertySkeleton() {
  return (
    <div className="bg-card rounded-lg overflow-hidden shadow-md">
      <Skeleton className="aspect-[16/10] w-full" />
      <div className="p-4 space-y-3">
        <Skeleton className="h-6 w-1/3" />
        <Skeleton className="h-4 w-2/3" />
        <Skeleton className="h-4 w-1/2" />
        <div className="flex gap-4 pt-3 border-t">
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-20" />
        </div>
      </div>
    </div>
  );
}

interface FeaturedPropertiesProps {
  searchQuery?: string;
}

export function FeaturedProperties({ searchQuery }: FeaturedPropertiesProps) {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const queryUrl = searchQuery 
    ? `/api/properties/search?q=${encodeURIComponent(searchQuery)}`
    : "/api/properties/featured";

  const { data: properties, isLoading } = useQuery<Property[]>({
    queryKey: [queryUrl],
  });

  const handleFavorite = (id: string) => {
    setFavorites(prev => {
      const newFavorites = new Set(prev);
      if (newFavorites.has(id)) {
        newFavorites.delete(id);
        toast({
          title: "Removed from favorites",
          description: "Property removed from your saved list.",
        });
      } else {
        newFavorites.add(id);
        toast({
          title: "Added to favorites",
          description: "Property saved to your favorites!",
        });
      }
      return newFavorites;
    });
  };

  return (
    <section id="properties" className="py-16 lg:py-24 px-4 lg:px-8 bg-muted/30" ref={sectionRef}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-10"
        >
          <div>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-2" data-testid="text-properties-title">
              {searchQuery ? `Search Results for "${searchQuery}"` : "Featured Listings"}
            </h2>
            <p className="text-muted-foreground" data-testid="text-properties-description">
              {searchQuery 
                ? `Found ${properties?.length || 0} properties matching your search`
                : "Discover hand-picked properties in Toronto's most desirable neighborhoods"}
            </p>
          </div>
          <Button variant="outline" className="gap-2" data-testid="button-all-properties">
            View All Listings
            <ArrowRight className="w-4 h-4" />
          </Button>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <>
              <PropertySkeleton />
              <PropertySkeleton />
              <PropertySkeleton />
            </>
          ) : properties && properties.length > 0 ? (
            properties.map((property, index) => (
              <PropertyCard 
                key={property.id} 
                property={property} 
                index={index}
                onFavorite={handleFavorite}
                isFavorited={favorites.has(property.id)}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground" data-testid="text-no-properties">
                {searchQuery 
                  ? "No properties found matching your search. Try a different location or keyword."
                  : "No featured properties available at the moment."}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
