import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import { SiInstagram } from "react-icons/si";
import { Button } from "@/components/ui/button";
import logoUrl from "@assets/image_1768945695247.png";

const navItems = [
  { label: "Home", href: "#hero" },
  { label: "Properties", href: "#properties" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("Home");

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
      
      const sections = [
        { id: "contact", label: "Contact" },
        { id: "about", label: "About" },
        { id: "properties", label: "Properties" },
        { id: "hero", label: "Home" },
      ];
      
      for (const section of sections) {
        const element = document.getElementById(section.id);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 150 && rect.bottom > 150) {
            setActiveSection(section.label);
            break;
          }
        }
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (href: string, label: string) => {
    if (href === "#hero") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    }
    setActiveSection(label);
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <motion.header
        initial={{ y: -100, opacity: 0 }}
        animate={{ 
          y: isScrolled ? 0 : -100, 
          opacity: isScrolled ? 1 : 0 
        }}
        transition={{ duration: 0.3, ease: "easeOut" }}
        className="fixed top-4 left-0 right-0 z-50 hidden lg:flex justify-center"
      >
        <div className="bg-white/95 backdrop-blur-md rounded-full shadow-lg px-3 py-2 border border-border/50">
          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => scrollToSection(item.href, item.label)}
                className={`relative px-5 py-2 text-sm font-medium rounded-full transition-all duration-300 ${
                  activeSection === item.label
                    ? "text-primary-foreground"
                    : "text-foreground/70 hover:text-foreground"
                }`}
                data-testid={`link-nav-${item.label.toLowerCase()}`}
              >
                {activeSection === item.label && (
                  <motion.div
                    layoutId="activeSection"
                    className="absolute inset-0 bg-primary rounded-full"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </motion.header>

      <div className="fixed top-0 left-0 right-0 z-50 lg:hidden">
        <motion.div
          initial={{ y: -100, opacity: 0 }}
          animate={{ 
            y: isScrolled ? 0 : -100, 
            opacity: isScrolled ? 1 : 0 
          }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="bg-white/95 backdrop-blur-md shadow-lg mx-4 mt-4 rounded-full px-4 py-2 border border-border/50"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-foreground px-2">
              {activeSection}
            </span>

            <Button
              variant="ghost"
              size="icon"
              className="rounded-full"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </Button>
          </div>
        </motion.div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-background lg:hidden pt-20"
          >
            <div className="flex flex-col p-6 gap-2">
              {navItems.map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.3 }}
                >
                  <Button
                    variant={activeSection === item.label ? "default" : "ghost"}
                    size="lg"
                    className="w-full justify-start rounded-full"
                    onClick={() => scrollToSection(item.href, item.label)}
                    data-testid={`link-mobile-${item.label.toLowerCase()}`}
                  >
                    {item.label}
                  </Button>
                </motion.div>
              ))}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4, duration: 0.3 }}
              >
                <a
                  href="https://www.instagram.com/adnaanvania"
                  target="_blank"
                  rel="noopener noreferrer"
                  data-testid="link-mobile-instagram"
                >
                  <Button
                    variant="ghost"
                    size="lg"
                    className="w-full justify-start gap-2 rounded-full"
                  >
                    <SiInstagram className="w-5 h-5" />
                    @adnaanvania
                  </Button>
                </a>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
