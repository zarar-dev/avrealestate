import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Home, TrendingUp, Building2, Key, BarChart3, Users } from "lucide-react";
import { Card } from "@/components/ui/card";

const services = [
  {
    icon: Home,
    title: "Home Buying",
    description: "Find your perfect home with personalized search and expert guidance through every step of the buying process.",
  },
  {
    icon: TrendingUp,
    title: "Home Selling",
    description: "Get top dollar for your property with strategic pricing, professional marketing, and skilled negotiation.",
  },
  {
    icon: Building2,
    title: "Pre-Construction",
    description: "Access exclusive pre-construction opportunities and expert advice on the best investments.",
  },
  {
    icon: Key,
    title: "Rentals",
    description: "Whether you're looking to rent or lease your property, I'll help you find the perfect match.",
  },
  {
    icon: BarChart3,
    title: "Market Analysis",
    description: "Get detailed market insights and property valuations to make informed decisions.",
  },
  {
    icon: Users,
    title: "First-Time Buyers",
    description: "Special programs and guidance for first-time homebuyers navigating the Toronto market.",
  },
];

function ServiceCard({ service, index }: { service: typeof services[0]; index: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const Icon = service.icon;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Card
        className="group p-6 hover-elevate"
        data-testid={`card-service-${service.title.toLowerCase().replace(/\s+/g, '-')}`}
      >
        <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
          <Icon className="w-6 h-6 text-primary" />
        </div>
        
        <h3 className="font-semibold text-lg text-foreground mb-2" data-testid={`text-service-title-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
          {service.title}
        </h3>
        
        <p className="text-muted-foreground text-sm leading-relaxed" data-testid={`text-service-desc-${service.title.toLowerCase().replace(/\s+/g, '-')}`}>
          {service.description}
        </p>
      </Card>
    </motion.div>
  );
}

export function Services() {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });

  return (
    <section id="services" className="py-16 lg:py-24 px-4 lg:px-8" ref={sectionRef}>
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto mb-12"
        >
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4" data-testid="text-services-title">
            How I Can Help You
          </h2>
          <p className="text-muted-foreground" data-testid="text-services-description">
            Full-service real estate solutions tailored to your unique needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <ServiceCard key={service.title} service={service} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
