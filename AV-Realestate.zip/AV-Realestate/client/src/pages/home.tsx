import { useState } from "react";
import { Header } from "@/components/header";
import { Hero } from "@/components/hero";
import { FeaturedProperties } from "@/components/featured-properties";
import { Services } from "@/components/services";
import { Trust } from "@/components/trust";
import { Contact } from "@/components/contact";
import { Footer } from "@/components/footer";

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (query: string, type: string) => {
    setSearchQuery(query);
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />
      <main>
        <Hero onSearch={handleSearch} />
        <FeaturedProperties searchQuery={searchQuery} />
        <Services />
        <Trust />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
