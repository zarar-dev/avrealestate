# Adnaan Vania Real Estate Website

## Overview

A modern real estate website for Adnaan Vania, a Toronto-based real estate professional. The application is a single-page marketing site featuring property listings, services, testimonials, and contact form functionality. Built with React frontend and Express backend using a fullstack TypeScript architecture. Inspired by realtor.com with a clean, light design and red accent colors.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **January 2026**: Redesigned from dark luxury theme to light realtor.com-inspired theme
- **January 2026**: Updated all branding from "Marcus Chen" to "Adnaan Vania"
- **January 2026**: Added Instagram integration (@adnaanvania) throughout the site
- **January 2026**: Redesigned hero section with prominent property search bar
- **January 2026**: Added testimonials section with client reviews
- **January 2026**: Updated color scheme to white/light gray with red primary accent

## Design Choices

- **Color Scheme**: Light backgrounds (white), red primary accent (hsl 0 84% 60%), dark text
- **Typography**: Inter for body text, system fonts for headers
- **Layout**: Search-focused hero with property search bar, card-based property listings
- **Instagram**: @adnaanvania linked in about section, contact section, and footer

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and data fetching
- **Styling**: Tailwind CSS with light modern theme using CSS variables
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Animations**: Framer Motion for scroll-based and interactive animations
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Framework**: Express 5 on Node.js
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful JSON API with `/api` prefix
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Validation**: Zod with drizzle-zod for type-safe schemas
- **Storage Pattern**: Interface-based storage abstraction (currently in-memory with seeded sample properties)

### Shared Code
- **Location**: `shared/` directory for code shared between client and server
- **Schema**: Database schemas and Zod validation schemas defined in `shared/schema.ts`
- **Type Safety**: Full end-to-end TypeScript with shared types

### Project Structure
```
├── client/           # React frontend
│   ├── src/
│   │   ├── components/   # UI components (shadcn + custom)
│   │   ├── pages/        # Page components
│   │   ├── hooks/        # Custom React hooks
│   │   └── lib/          # Utilities and query client
├── server/           # Express backend
│   ├── index.ts      # Server entry point
│   ├── routes.ts     # API route definitions
│   ├── storage.ts    # Data storage layer (in-memory with sample properties)
│   └── vite.ts       # Vite dev server integration
├── shared/           # Shared types and schemas
└── migrations/       # Drizzle database migrations
```

## API Endpoints

- `GET /api/properties/featured` - Returns array of featured property listings
- `GET /api/properties/:id` - Returns single property by ID
- `POST /api/contact` - Submits contact form inquiry

## External Dependencies

### Database
- **PostgreSQL**: Primary database (configured via `DATABASE_URL` environment variable)
- **Drizzle Kit**: Database migrations with `db:push` command
- **Auto-seeding**: Database is automatically seeded with 6 sample Toronto properties on startup if empty

### UI Framework
- **Radix UI**: Headless UI primitives for accessibility
- **shadcn/ui**: Pre-configured component library (new-york style)
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Icon library
- **React Icons**: Additional icon sets (social media icons for Instagram)

### Form & Validation
- **Zod**: Schema validation
- **React Hook Form**: Form state management
- **zod-validation-error**: Human-readable validation errors

### Animation & Interaction
- **Framer Motion**: Animation library
- **Embla Carousel**: Carousel/slider functionality
- **Vaul**: Drawer component

### Build & Development
- **Vite**: Frontend build tool
- **esbuild**: Server bundling for production
- **tsx**: TypeScript execution for development
